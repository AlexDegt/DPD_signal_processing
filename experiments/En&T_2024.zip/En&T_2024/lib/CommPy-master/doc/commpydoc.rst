.. CommPy documentation master file, created by
   sphinx-quickstart on Sun Jan 29 23:37:16 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

CommPy
==================================

CommPy is an open source package implementing digital communications algorithms
in Python using NumPy, SciPy and Matplotlib.

Reference
---------
.. toctree::
    :maxdepth: 2

    channelcoding
    channels
    filters
    sequences
