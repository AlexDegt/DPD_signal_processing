.. automodule:: commpy.impairments
