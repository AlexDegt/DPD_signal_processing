.. automodule:: commpy.channels
