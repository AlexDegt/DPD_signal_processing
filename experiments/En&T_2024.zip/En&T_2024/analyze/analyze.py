# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 16:02:52 2023

@author: dWX1065688
"""
import sys, os
sys.path.insert(0, r'../lib')
import plot_lib as pl
import support_lib as sl
import numpy as np
import matplotlib.pyplot as plt
import scipy.signal as signal
from scipy import interpolate
from copy import deepcopy
from scipy.io import loadmat, savemat

tx = np.load('x.npy')
pa_out = np.load('d.npy')
model_out = np.load('y.npy')

tap_num = 1

power_cases = [-15, -12, -9, -6, -3, 0]

sig_len = int(len(tx) / len(power_cases))

for i in range(len(power_cases)):
    x = tx[i * sig_len: (i + 1) * sig_len]
    d = pa_out[i * sig_len: (i + 1) * sig_len]
    y = model_out[i * sig_len: (i + 1) * sig_len]
    nmse = sl.nmse(d, d - y)
    print(f"Case {power_cases[i]} dB: NMSE = {nmse} dB")
    plt.figure(i + 1)
    plt.title(f"Power case {power_cases[i]} dB")
    pl.plot_psd(x + d, x + d - y, nfig=i + 1)
    